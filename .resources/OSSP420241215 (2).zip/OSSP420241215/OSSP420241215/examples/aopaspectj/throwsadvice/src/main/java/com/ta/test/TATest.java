package com.ta.test;

import com.ta.beans.Thrower;
import com.ta.config.TAConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TATest {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(TAConfig.class);
        Thrower thrower = applicationContext.getBean("thrower", Thrower.class);

        int i = thrower.willThrow(-1);
        System.out.println("i : " + i);
    }
}
