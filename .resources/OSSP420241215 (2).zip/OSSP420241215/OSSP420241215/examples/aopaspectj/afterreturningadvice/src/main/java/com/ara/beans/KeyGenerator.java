package com.ara.beans;

import org.springframework.stereotype.Component;

@Component
public class KeyGenerator {
    public int generate(int len) {
        if (len < 8) {
            return 0;
        }
        return 1;
    }
}
