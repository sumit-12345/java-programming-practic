package com.ara.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class KeyValidationAspect {
    @AfterReturning(value = "execution(* com.ara.beans.KeyGenerator.generate(..))", returning = "ret")
    public void validate(JoinPoint jp, Object ret) {
        int key = (Integer) ret;

        if (key <= 0) { // weak key
            throw new RuntimeException("weak key generated");
        }
    }
}
