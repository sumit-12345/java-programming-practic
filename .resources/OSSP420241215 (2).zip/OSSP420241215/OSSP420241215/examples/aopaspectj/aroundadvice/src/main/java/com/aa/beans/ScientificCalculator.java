package com.aa.beans;

import org.springframework.stereotype.Component;

@Component
public class ScientificCalculator {
    public int substract(int a, int b) {
        System.out.println("in substract()");
        return b - a;
    }
}
