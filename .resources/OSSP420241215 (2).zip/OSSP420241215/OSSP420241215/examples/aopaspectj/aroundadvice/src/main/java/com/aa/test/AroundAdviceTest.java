package com.aa.test;

import com.aa.beans.Calculator;
import com.aa.beans.ScientificCalculator;
import com.aa.config.AroundAdviceConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class AroundAdviceTest {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AroundAdviceConfig.class);

        Calculator calculator = applicationContext.getBean("calculator1", Calculator.class);
        int sum = calculator.add(10, 20);
        System.out.println("sum : " + sum);

        sum = calculator.add(10, 20);
        System.out.println("sum : " + sum);

        ScientificCalculator scientificCalculator = applicationContext.getBean(ScientificCalculator.class);
        int sub = scientificCalculator.substract(10,20);
        System.out.println("substraction : " + sub);
    }
}
