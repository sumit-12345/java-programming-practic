package com.mba.test;

import com.mba.beans.LoanManager;
import com.mba.config.BeforeAdviceConfig;
import com.mba.helper.SecurityManager;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MBATest {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(BeforeAdviceConfig.class);

        LoanManager lm = applicationContext.getBean("loanManager", LoanManager.class);
        SecurityManager securityManager = applicationContext.getBean(SecurityManager.class);
        securityManager.login("fedrick", "welcome1");
        boolean approveLoan = lm.approveLoan("L038344");
        System.out.println("approved ? : " + approveLoan);
        securityManager.logout();
    }
}
