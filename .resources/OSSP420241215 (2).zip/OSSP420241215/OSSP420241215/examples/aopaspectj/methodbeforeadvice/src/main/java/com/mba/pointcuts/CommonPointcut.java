package com.mba.pointcuts;

import org.aspectj.lang.annotation.Pointcut;

public interface CommonPointcut {
    @Pointcut("execution(* com.mba.beans.LoanManager.*(..))")
    public default void securityPointcut() {
    }
}
