package com.mba.beans;

public class LoanManager {
    public boolean approveLoan(String loanNo) {
        System.out.println("evaluating the loan application of loanNo : " + loanNo);
        return true;
    }
}
