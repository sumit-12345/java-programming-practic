package com.mba.test;

import com.mba.advice.AuditAdvice;
import com.mba.advice.SecurityCheckAdvice;
import com.mba.beans.LoanManager;
import com.mba.helper.SecurityManager;
import org.springframework.aop.framework.ProxyFactory;

public class BeforeAdviceTest {
    public static void main(String[] args) {
        ProxyFactory pf = new ProxyFactory();
        pf.setTarget(new LoanManager());

        // the order in which we added the advices in the same order those are applied on the target class
        pf.addAdvice(new AuditAdvice());
        pf.addAdvice(new SecurityCheckAdvice()); // invalid-attempt

        LoanManager proxy = (LoanManager) pf.getProxy();

        SecurityManager manager = SecurityManager.getInstance();
        manager.login("john", "aop@1");
        boolean status = proxy.approveLoan("L93833");
        manager.logout();
        System.out.println("loan approved ? : " + status);
    }
}
