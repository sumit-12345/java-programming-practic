package com.bscopes.beans;

public class Game {
    public void start() {
        System.out.println("game started...");
    }
}
