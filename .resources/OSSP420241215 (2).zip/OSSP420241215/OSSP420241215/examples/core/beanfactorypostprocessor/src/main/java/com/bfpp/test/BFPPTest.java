package com.bfpp.test;

import com.bfpp.beans.OrderService;
import com.bfpp.config.BFPPJavaConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import javax.sound.midi.Soundbank;
import java.util.Arrays;
import java.util.Collections;
import java.util.Locale;
import java.util.Properties;

public class BFPPTest {
    public static void main(String[] args) {
        /*ApplicationContext applicationContext = new AnnotationConfigApplicationContext(BFPPJavaConfig.class);
        OrderService orderService = applicationContext.getBean(OrderService.class);

        orderService.checkout(Collections.emptyList());

        Arrays.stream(applicationContext.getBeanDefinitionNames()).forEach(System.out::println);*/
        Locale locale = Locale.getDefault();
        Properties props = System.getProperties();
        props.forEach((k,v)->{
            System.out.println(k + " : " + v);
        });

        //System.out.println("Country : " + locale.getCountry() + " Lang : " + locale.getLanguage());
    }
}
