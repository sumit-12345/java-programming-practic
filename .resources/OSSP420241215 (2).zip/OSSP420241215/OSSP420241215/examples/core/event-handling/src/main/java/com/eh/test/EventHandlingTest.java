package com.eh.test;

import com.eh.beans.UpdateCityService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.time.LocalDateTime;

public class EventHandlingTest {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext("com.eh.beans",
                "com.eh.listener");
        UpdateCityService updateCityService = applicationContext.getBean(UpdateCityService.class);

        updateCityService.updateCity(10, "Chennai");

    }
}
