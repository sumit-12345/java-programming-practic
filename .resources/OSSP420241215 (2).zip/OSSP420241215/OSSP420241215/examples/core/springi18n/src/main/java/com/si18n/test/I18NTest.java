package com.si18n.test;

import com.si18n.config.I18NConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.Locale;

public class I18NTest {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(I18NConfig.class);

        MessageSource messageSource = applicationContext.getBean(MessageSource.class);
        String message = messageSource.getMessage("age.invalid", null, Locale.JAPAN);
        System.out.println(message);
    }
}
