package com.don.test;

import com.don.beans.LoanCalculatorService;
import com.don.config.DONJavaConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.io.IOException;

public class DONTest {
    public static void main(String[] args) throws IOException {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(DONJavaConfig.class);
        LoanCalculatorService loanCalculatorService = applicationContext.getBean(LoanCalculatorService.class);

        double interestAmount = loanCalculatorService.calculateInterestAmount(100000, 12, 735, "personal", "hyderabad");
        System.out.println("interest to be paid : " + interestAmount);
    }
}
