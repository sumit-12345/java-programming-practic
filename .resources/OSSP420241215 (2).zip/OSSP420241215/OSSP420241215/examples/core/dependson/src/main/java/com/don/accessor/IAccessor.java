package com.don.accessor;

public interface IAccessor {
    String getKey();
    Object getData();
}
