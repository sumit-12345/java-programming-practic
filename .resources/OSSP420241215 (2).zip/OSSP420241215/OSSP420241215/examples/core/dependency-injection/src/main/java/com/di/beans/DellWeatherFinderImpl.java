package com.di.beans;

public class DellWeatherFinderImpl implements IWeatherFinder {
    @Override
    public double getWeather(String zipCode) {
        return 40;
    }
}
