package com.di.beans;

public class OracleWeatherFinderImpl implements IWeatherFinder{
    @Override
    public double getWeather(String zipCode) {
        return 50;
    }
}
