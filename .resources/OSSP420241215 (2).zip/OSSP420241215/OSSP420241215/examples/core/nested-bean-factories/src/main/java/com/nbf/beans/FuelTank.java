package com.nbf.beans;

import lombok.Setter;
import lombok.ToString;

@Setter
@ToString
public class FuelTank {
    private String fuelType;
    private int capacity;


}
