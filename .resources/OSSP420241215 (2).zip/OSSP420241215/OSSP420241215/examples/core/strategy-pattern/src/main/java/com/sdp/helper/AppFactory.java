package com.sdp.helper;

import java.io.IOException;
import java.util.Properties;

public class AppFactory {
    public static Object createObject(String lClassname) throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Object obj = null;
        Class clazz = null;
        String fqnClassname = null;
        Properties properties = null;

        properties = new Properties();
        properties.load(AppFactory.class.getClassLoader().getResourceAsStream("com/sdp/common/appClasses.properties"));

        fqnClassname = properties.getProperty(lClassname);
        clazz = Class.forName(fqnClassname);
        obj = clazz.newInstance();

        return obj;
    }
}
