package com.sdp.beans;

public class MessageWriter {
    private IMessageConverter messageConverter;

    public void writeMessage(String message) {
        String convertedMessage = null;

        //messageConverter = new PDFMessageConverterImpl();
        //messageConverter = MessageConverterFactory.createMessageConverter("pdf");

        convertedMessage = messageConverter.convertMessage(message);
        System.out.println(convertedMessage);
    }

    public void setMessageConverter(IMessageConverter messageConverter) {
        this.messageConverter = messageConverter;
    }
}
