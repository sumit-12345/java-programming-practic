package com.sdp.beans;

public class DigitalBoard {
    private IMessageConverter messageConverter;

    public void on(String message) {
        String cMessage = null;

        cMessage = messageConverter.convertMessage(message);
        System.out.println(cMessage);
    }

    public void setMessageConverter(IMessageConverter messageConverter) {
        this.messageConverter = messageConverter;
    }
}
