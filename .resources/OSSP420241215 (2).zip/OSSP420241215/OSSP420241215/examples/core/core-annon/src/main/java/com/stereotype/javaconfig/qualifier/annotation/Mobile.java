package com.stereotype.javaconfig.qualifier.annotation;

import org.springframework.beans.factory.annotation.Qualifier;

// no sourcecode
public class Mobile {
    private INetworkProvider networkProvider;

    public void reqESim(String packageName, String cid) {
        String eSim = networkProvider.eSim(packageName, cid);
        System.out.println("registering the mobile onto the network provider with eSim : " + eSim);
    }

    public void setNetworkProvider(INetworkProvider networkProvider) {
        this.networkProvider = networkProvider;
    }
}
