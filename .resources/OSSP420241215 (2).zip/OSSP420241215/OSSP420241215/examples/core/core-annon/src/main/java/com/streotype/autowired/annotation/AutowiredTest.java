package com.streotype.autowired.annotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class AutowiredTest {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(AutowiredJavaConfig.class);
        Toy toy = context.getBean("toy", Toy.class);
        toy.play();
    }
}
