package com.primitiveinjection.javaconfig.annotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class PrimitiveInjectionJavaConfigTest {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(PrimitiveInjectionJavaConfig.class);
        Branch branch1 = applicationContext.getBean("branch2", Branch.class);
        System.out.println(branch1);
    }
}
