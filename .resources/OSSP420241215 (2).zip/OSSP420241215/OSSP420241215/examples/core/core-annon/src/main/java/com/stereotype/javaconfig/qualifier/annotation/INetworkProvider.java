package com.stereotype.javaconfig.qualifier.annotation;

public interface INetworkProvider {
    String eSim(String packageName, String cid);
}
