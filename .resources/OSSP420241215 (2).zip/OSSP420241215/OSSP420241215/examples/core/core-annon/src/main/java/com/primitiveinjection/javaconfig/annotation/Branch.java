package com.primitiveinjection.javaconfig.annotation;

import lombok.Data;

// no sourcecode
@Data
public class Branch {
    private int id;
    private String ifscCode;
    private String branchName;
    private String location;
}
