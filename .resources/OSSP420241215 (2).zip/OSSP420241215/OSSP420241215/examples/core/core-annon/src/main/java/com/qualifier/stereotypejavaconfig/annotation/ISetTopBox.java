package com.qualifier.stereotypejavaconfig.annotation;

public interface ISetTopBox {
    void stream(String channelNo);
}
