package com.qualifier.stereotypejavaconfig.annotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

// sourcecode
@Component
public class Television {
    @Autowired
    @Qualifier("preferred")
    private ISetTopBox setTopBox;

    public void on() {
        setTopBox.stream("01");
        System.out.println("on and streaming ...");
    }
}

