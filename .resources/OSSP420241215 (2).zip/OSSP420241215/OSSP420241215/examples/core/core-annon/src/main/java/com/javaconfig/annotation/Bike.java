package com.javaconfig.annotation;

// no sourcecode
public class Bike {

    public void accelerate() {
        System.out.println("accelerating the bike!");
    }
}
