package com.stereotype.javaconfig.qualifier.annotation;

import org.springframework.stereotype.Component;

import java.util.UUID;

// sourcecode
@Component("jioNetworkProvider")
public class JioNetworkProviderImpl implements INetworkProvider {
    @Override
    public String eSim(String packageName, String cid) {
        System.out.println("jio eSim generated...");
        return UUID.randomUUID().toString();
    }
}
