package com.spc.beans;

public interface IMessageConverter {
    String convertMessage(String message);
}
