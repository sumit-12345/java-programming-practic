package com.ai.beans;

public interface SetTopBox {
    void on();
}
