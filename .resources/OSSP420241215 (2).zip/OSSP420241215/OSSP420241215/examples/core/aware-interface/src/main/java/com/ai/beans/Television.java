package com.ai.beans;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

@Component
public class Television implements ApplicationContextAware {
    private SetTopBox setTopBox;
    private ApplicationContext applicationContext;

    public void powerOn() {
        setTopBox = applicationContext.getBean("jioStandardSetTopBox", SetTopBox.class);
        setTopBox.on();
        System.out.println("watching television!");
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
}
