package com.cdi.beans;

import java.util.Map;
import java.util.Properties;

public class University {
    private Map<String, Course> courseHodMap;
    private Properties courseToppers;

    public University(Map<String, Course> courseHodMap, Properties courseToppers) {
        this.courseHodMap = courseHodMap;
        this.courseToppers = courseToppers;
    }

    @Override
    public String toString() {
        return "University{" +
                "courseHodMap=" + courseHodMap +
                ", courseToppers=" + courseToppers +
                '}';
    }
}
