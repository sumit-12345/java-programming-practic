package com.qa.test;

import com.qa.bo.StudentBo;
import com.qa.config.JavaConfig;
import com.qa.dao.AutoStudentDao;
import com.qa.dao.StudentDao;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class QATest {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(JavaConfig.class);

        StudentDao dao = applicationContext.getBean(StudentDao.class);
        //dao.findStudentsWithCourses("F").forEach(System.out::println);

        dao.findStudentsByPage(3).forEach(System.out::println);

        /*long count = dao.countStudents();
        System.out.println("count : " + count);*/
        /*String studentName = dao.findStudentNameById(2);
        System.out.println("student name : " + studentName);*/
        //System.out.println(dao.findByStudentNo(1));
        //dao.findByGender("F").forEach(System.out::println);

        //dao.findStudentContact(20, 25).forEach(System.out::println);
        /*int r = dao.saveStudent(StudentBo.of().studentNo(5).studentName("Christian")
                .age(34).gender("M")
                .mobileNo("9938378334")
                .emailAddress("christian@gmail.com").build());
        System.out.println("records inserted : " + r);*/
        /*AutoStudentDao autoStudentDao = applicationContext.getBean(AutoStudentDao.class);
        int studentNo = autoStudentDao.saveStudentNP(StudentBo.of().studentName("Jason")
                .age(28).gender("M")
                .mobileNo("98987788")
                .emailAddress("json@gmail.com").build());
        System.out.println("student no : " + studentNo);*/
    }
}
