package com.ca.dao;

import com.ca.bo.CourseBo;
import lombok.AllArgsConstructor;
import org.checkerframework.checker.units.qual.A;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.StatementCallback;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

@Repository
@AllArgsConstructor
public class CourseDao {
    private final static String SQL_FIND_ALL_COURSES = "select course_no, course_nm, duration, fee from course order by course_nm";

    private final JdbcTemplate jdbcTemplate;

    public List<CourseBo> findAll() {
        return jdbcTemplate.execute(new CourseStatementCallback());
    }

    private final class CourseStatementCallback implements StatementCallback<List<CourseBo>> {
        @Override
        public List<CourseBo> doInStatement(Statement stmt) throws SQLException, DataAccessException {
            final ResultSet resultSet = stmt.executeQuery(SQL_FIND_ALL_COURSES);
            final List<CourseBo> courseBos = new ArrayList<>();

            while(resultSet.next()) {
                courseBos.add(CourseBo.of().courseNo(resultSet.getInt(1))
                        .courseName(resultSet.getString(2))
                        .duration(resultSet.getInt(3))
                        .fee(resultSet.getDouble(4)).build());
            }

            return courseBos;
        }
    }
}







