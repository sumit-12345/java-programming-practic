package com.ca.test;

import com.ca.bo.StudentBo;
import com.ca.config.JavaConfig;
import com.ca.dao.CourseDao;
import com.ca.dao.StudentDao;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ClassicApproachTest {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(JavaConfig.class);

        StudentDao dao = applicationContext.getBean(StudentDao.class);
        //dao.findStudentsBetweenAge(23, 25).stream().forEach(System.out::println);
        //dao.findAll().stream().forEach(System.out::println);
        //dao.findStudentsByGender("M").stream().forEach(System.out::println);
        /*int records = dao.saveStudent(StudentBo.of().studentNo(4).studentName("Robert").age(23).gender("M").mobileNo("9894784833").emailAddress("robert@yahoo.com").build());
        System.out.println("records inserted : " + records);*/

        CourseDao courseDao = applicationContext.getBean(CourseDao.class);
        courseDao.findAll().forEach(System.out::println);
    }
}
